import React from 'react'

export default function Footer() {
  return (
    <div>
      footer part
    </div>
  )
}
